import json
import base64
import cv2
import numpy as np
from fastapi import FastAPI, WebSocket
from fastapi.middleware.cors import CORSMiddleware

from backend.pose_detector import PoseDetector
from exercises.knee_raise import KneeRaiseExercise
from exercises.lunge import LungeExercise
from exercises.shoulder import ShoulderAbduction

app = FastAPI()
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

detector = PoseDetector()

exercise_map = {
    "knee_raise": KneeRaiseExercise(),
    "lunge": LungeExercise(),
    "shoulder": ShoulderAbduction()
}

@app.websocket("/ws")
async def websocket_endpoint(ws: WebSocket):
    await ws.accept()
    current = None

    while True:
        try:
            data = json.loads(await ws.receive_text())

            name = data.get("exercise")
            if current is None or current.name != name:
                current = exercise_map.get(name)
                if current:
                    current.reset()

            if current is None:
                await ws.send_json({"error": "Invalid exercise"})
                continue

            # Decode image
            img_bytes = base64.b64decode(data["frame"])
            img = cv2.imdecode(np.frombuffer(img_bytes, np.uint8), cv2.IMREAD_COLOR)

            detector.findPose(img)
            lm = detector.getLandmarks(img)

            _, feedback, count = current.detect(img, lm)

            await ws.send_json({
                "feedback": feedback,
                "count": count,
                "landmarks": {str(k): v for k, v in lm.items()}
            })

        except Exception as e:
            await ws.send_json({"error": str(e)})
