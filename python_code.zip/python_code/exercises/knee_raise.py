from exercises.base import ExerciseBase

class KneeRaiseExercise(ExerciseBase):
    def __init__(self):
        super().__init__("knee_raise")

    def detect(self, img, lm):
        required = [11, 12, 23, 24, 25, 26, 27, 28]
        if not all(k in lm for k in required):
            return img, "No Pose", self.count

        # Hip angles
        l_hip = self.calculate_angle(lm[11], lm[23], lm[25])
        r_hip = self.calculate_angle(lm[12], lm[24], lm[26])

        # Reset condition (both legs down)
        if l_hip > 160 and r_hip > 160:
            if self.stage == "up":
                self.count += 1
                self.stage = "down"
            return img, "Ready", self.count

        # Detect active leg
        if l_hip < r_hip:
            hip_angle = l_hip
            knee_angle = self.calculate_angle(lm[23], lm[25], lm[27])
        else:
            hip_angle = r_hip
            knee_angle = self.calculate_angle(lm[24], lm[26], lm[28])

        # Feedback logic
        if knee_angle > 120:
            feedback = "Bend Knee"
        elif hip_angle > 100:
            feedback = "Higher"
        else:
            feedback = "Good"
            self.stage = "up"

        return img, feedback, self.count
