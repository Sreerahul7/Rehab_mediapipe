from exercises.base import ExerciseBase

class ShoulderAbduction(ExerciseBase):
    def __init__(self):
        super().__init__("shoulder")

    def detect(self, img, lm):
        l_angle = 0
        r_angle = 0

        if all(k in lm for k in [23, 11, 13]):
            l_angle = self.calculate_angle(lm[23], lm[11], lm[13])

        if all(k in lm for k in [24, 12, 14]):
            r_angle = self.calculate_angle(lm[24], lm[12], lm[14])

        active = max(l_angle, r_angle)

        if active >= 80 and self.stage == "down":
            self.stage = "up"
            return img, "Good", self.count

        if active <= 30 and self.stage == "up":
            self.stage = "down"
            self.count += 1

        return img, "Fix", self.count
