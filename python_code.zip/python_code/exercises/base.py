import math

class ExerciseBase:
    def __init__(self, name):
        self.name = name
        self.count = 0
        self.stage = "down"

    def reset(self):
        self.count = 0
        self.stage = "down"

    def calculate_angle(self, p1, p2, p3):
        a = math.dist(p2, p3)
        b = math.dist(p1, p3)
        c = math.dist(p1, p2)

        if a == 0 or c == 0:
            return 180

        val = (a*a + c*c - b*b) / (2*a*c)
        val = max(-1.0, min(1.0, val))  # ✅ CLAMP

        return int(math.degrees(math.acos(val)))
