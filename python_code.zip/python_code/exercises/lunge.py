from exercises.base import ExerciseBase

class LungeExercise(ExerciseBase):
    def __init__(self):
        super().__init__("lunge")
        self.stage = "up"

    def detect(self, img, lm):
        angle = 180

        if all(k in lm for k in [23, 25, 27]):
            angle = self.calculate_angle(lm[23], lm[25], lm[27])
        elif all(k in lm for k in [24, 26, 28]):
            angle = self.calculate_angle(lm[24], lm[26], lm[28])
        else:
            return img, "No Pose", self.count

        if angle <= 100:
            self.stage = "down"
            return img, "Good", self.count

        if angle >= 150 and self.stage == "down":
            self.stage = "up"
            self.count += 1
            return img, "Ready", self.count

        return img, "Fix", self.count
